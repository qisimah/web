module.exports = {
    prod: [
        "dist/css/"
    ],
    dev: [
        "test/css/"
    ],
    'less-temp': [
        "less/temp/"
    ],
    'sass-temp': [
        "scss/temp/"
    ]
};
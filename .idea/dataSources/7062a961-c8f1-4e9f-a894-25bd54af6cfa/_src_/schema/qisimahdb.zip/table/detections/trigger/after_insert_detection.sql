CREATE TRIGGER `after_insert_detection`
AFTER INSERT ON `detections`
FOR EACH ROW
  BEGIN
  SET @count = (SELECT count(*) FROM detections WHERE acr_id=new.acr_id);
  REPLACE INTO counts (acr_id, stream_id, count, created_at, updated_at) VALUES (new.acr_id, new.stream_id, @count, new.created_at, new.updated_at);
END